import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
    module.exports = {
        content: [
          './resources/**/*.blade.php',
          './resources/**/*.js',
          './resources/**/*.vue',
        ],
        theme: {
          extend: {
            colors: {
              neonPink: '#ff007c',
              neonBlue: '#00d9ff',
              cyberYellow: '#ffe600',
              darkPurple: '#240046',
              lightPurple: '#7b2cbf',
              background: '#0f0f0f',
              gridLines: '#212121',
            },
            fontFamily: {
              cyber: ['"Press Start 2P"', 'cursive'],
            },
          },
        },
        plugins: [],
      };
      

