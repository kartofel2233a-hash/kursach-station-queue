@extends('layouts.app')

@section('content')
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Редагувати категорію</h1>

        <form action="{{ route('categories.update', $category) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-4">
                <label for="name" class="block text-lightPurple mb-2">Назва:</label>
                <input type="text" name="name" id="name" value="{{ $category->name }}" class="w-full p-2 rounded bg-darkPurple text-white" required>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-lightPurple mb-2">Опис:</label>
                <textarea name="description" id="description" class="w-full p-2 rounded bg-darkPurple text-white">{{ $category->description }}</textarea>
            </div>
            <button type="submit" class="bg-neonBlue text-background font-bold py-3 px-6 rounded hover:bg-cyberYellow">
                Зберегти
            </button>
        </form>
    </div>
@endsection
