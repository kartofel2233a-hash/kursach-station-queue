@extends('layouts.app')

@section('content')
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Управління категоріями</h1>

        <!-- Кнопка додавання нової категорії -->
        <div class="mb-6">
            <a href="{{ route('categories.create') }}" class="bg-neonBlue text-background font-bold py-3 px-6 rounded hover:bg-cyberYellow">
                Додати категорію
            </a>
        </div>

        <!-- Таблиця категорій -->
        <table class="w-full text-lightPurple border-collapse border border-darkPurple">
            <thead>
                <tr class="bg-darkPurple text-neonPink">
                    <th class="border border-darkPurple px-4 py-2">ID</th>
                    <th class="border border-darkPurple px-4 py-2">Назва</th>
                    <th class="border border-darkPurple px-4 py-2">Опис</th>
                    <th class="border border-darkPurple px-4 py-2">Дії</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($categories as $category)
                    <tr class="text-center">
                        <td class="border border-darkPurple px-4 py-2">{{ $category->id }}</td>
                        <td class="border border-darkPurple px-4 py-2">{{ $category->name }}</td>
                        <td class="border border-darkPurple px-4 py-2">{{ $category->description }}</td>
                        <td class="border border-darkPurple px-4 py-2">
                            <a href="{{ route('categories.edit', $category) }}" class="bg-neonBlue text-background py-2 px-4 rounded hover:bg-cyberYellow">
                                Редагувати
                            </a>
                            <form action="{{ route('categories.destroy', $category) }}" method="POST" style="display: inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded hover:bg-red-700">
                                    Видалити
                                </button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
