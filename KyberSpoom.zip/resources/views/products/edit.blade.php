@extends('layouts.app')

@section('content')
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Редагувати товар</h1>

        <form action="{{ route('products.update', $product) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="mb-4">
                <label for="name" class="block text-lightPurple mb-2">Назва:</label>
                <input type="text" name="name" id="name" value="{{ $product->name }}" class="w-full p-2 rounded bg-darkPurple text-white" required>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-lightPurple mb-2">Опис:</label>
                <textarea name="description" id="description" class="w-full p-2 rounded bg-darkPurple text-white" required>{{ $product->description }}</textarea>
            </div>
            <div class="mb-4">
                <label for="price" class="block text-lightPurple mb-2">Ціна:</label>
                <input type="number" name="price" id="price" value="{{ $product->price }}" class="w-full p-2 rounded bg-darkPurple text-white" required>
            </div>
            <div class="mb-4">
                <label for="category_id" class="block text-lightPurple mb-2">Категорія:</label>
                <select name="category_id" id="category_id" class="w-full p-2 rounded bg-darkPurple text-white" required>
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}" {{ $product->category_id == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="mb-4">
                <label for="image" class="block text-lightPurple mb-2">Зображення (необов'язково):</label>
                <input type="file" name="image" id="image" class="w-full p-2 bg-darkPurple text-lightPurple">
            </div>
            <button type="submit" class="bg-neonBlue text-background font-bold py-3 px-6 rounded hover:bg-cyberYellow">
                Зберегти
            </button>
        </form>
    </div>
@endsection
