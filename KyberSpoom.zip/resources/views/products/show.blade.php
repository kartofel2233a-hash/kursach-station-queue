@extends('layouts.app')

@section('content')
    <div class="min-h-screen bg-background p-6">
        <div class="bg-darkPurple p-6 rounded shadow-lg">
            <h1 class="text-4xl font-cyber text-neonPink mb-6">{{ $product->name }}</h1>

            @if ($product->image)
                <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="mb-6 rounded max-w-full">
            @endif

            <p class="text-lightPurple mb-6">{{ $product->description }}</p>
            <p class="text-cyberYellow font-bold text-xl mb-6">Ціна: ${{ $product->price }}</p>
            
            <!-- Відображення категорії товару -->
            @if ($product->category)
                <p class="text-neonPink mb-6">Категорія: <span class="text-lightPurple">{{ $product->category->name }}</span></p>
            @endif
            
            <a href="{{ route('products.shop') }}" class="bg-neonBlue text-background py-2 px-6 rounded hover:bg-cyberYellow">
                Повернутися до списку товарів
            </a>
        </div>
    </div>
@endsection
