@extends('layouts.app')

@section('content')
    <div class="text-center">
        <h1 class="text-5xl text-neonBlue animate__animated animate__fadeInDown">Ласкаво просимо до KyberSpoom!</h1>
        <p class="text-lightPurple mt-4 animate__animated animate__fadeInUp">Кіберпанковий магазин для сучасних технологій.</p>
    </div>
@endsection
