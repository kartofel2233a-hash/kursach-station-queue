@extends('layouts.app')

@section('content')
    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh; background-color: #0f0f0f;">
        <h1 style="font-size: 2.5rem; color: #ff007c; font-family: 'Press Start 2P', cursive; margin-bottom: 16px;">
            Профіль користувача
        </h1>

        <form method="POST" action="{{ route('profile.update') }}" style="width: 100%; max-width: 400px; background-color: #1c1c1c; padding: 16px; border-radius: 8px;">
            @csrf
            @method('PATCH')

            <!-- Поле для імені -->
            <div style="margin-bottom: 16px;">
                <label for="name" style="color: #ffe600; font-weight: bold;">Ім'я</label>
                <input type="text" name="name" id="name" value="{{ $user->name }}" required
                       style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #7b2cbf; margin-top: 8px; color: #ffe600; background-color: #333;">
            </div>

            <!-- Поле для email -->
            <div style="margin-bottom: 16px;">
                <label for="email" style="color: #ffe600; font-weight: bold;">Email</label>
                <input type="email" name="email" id="email" value="{{ $user->email }}" required
                       style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #7b2cbf; margin-top: 8px; color: #ffe600; background-color: #333;">
            </div>

            <!-- Поле для пароля -->
            <div style="margin-bottom: 16px;">
                <label for="password" style="color: #ffe600; font-weight: bold;">Новий пароль</label>
                <input type="password" name="password" id="password"
                       style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #7b2cbf; margin-top: 8px; color: #ffe600; background-color: #333;">
            </div>

            <!-- Поле для підтвердження пароля -->
            <div style="margin-bottom: 16px;">
                <label for="password_confirmation" style="color: #ffe600; font-weight: bold;">Підтвердження нового пароля</label>
                <input type="password" name="password_confirmation" id="password_confirmation"
                       style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #7b2cbf; margin-top: 8px; color: #ffe600; background-color: #333;">
            </div>

            <button type="submit" style="width: 100%; padding: 12px; background-color: #00d9ff; color: #0f0f0f; font-weight: bold; border: none; border-radius: 4px; cursor: pointer;">
                Оновити профіль
            </button>
        </form>
    </div>
@endsection
