@extends('layouts.app')

@section('content')
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Магазин товарів</h1>

        <!-- Пошук і фільтрація -->
        <form method="GET" action="{{ route('products.shop') }}" class="mb-6 flex flex-col lg:flex-row gap-4">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Пошук товарів..." class="w-full lg:w-1/3 p-2 rounded bg-darkPurple text-white">
            <select name="category" class="w-full lg:w-1/3 p-2 rounded bg-darkPurple text-white">
                <option value="">Усі категорії</option>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}" {{ request('category') == $category->id ? 'selected' : '' }}>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>
            <button type="submit" class="bg-neonBlue text-background font-bold py-2 px-6 rounded hover:bg-cyberYellow">
                Застосувати
            </button>
        </form>

        <!-- Список товарів -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    @forelse ($products as $product)
        <div class="bg-darkPurple p-4 rounded shadow-lg text-center">
            @if ($product->image)
                <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="mb-4 rounded max-h-40 mx-auto">
            @else
                <img src="{{ asset('default-product.png') }}" alt="Default Image" class="mb-4 rounded max-h-40 mx-auto">
            @endif
            <h2 class="text-neonPink text-2xl mb-4">{{ $product->name }}</h2>
            <p class="text-lightPurple mb-4">Ціна: ${{ $product->price }}</p>
            <a href="{{ route('products.shop.show', $product) }}" class="bg-neonBlue text-background py-2 px-4 rounded hover:bg-cyberYellow">
                Детальніше
            </a>
        </div>
    @empty
        <p class="text-lightPurple text-center col-span-3">Немає товарів за вашим запитом.</p>
    @endforelse
</div>


        <!-- Пагінація -->
        <div class="mt-6">
            {{ $products->links() }}
        </div>
    </div>
@endsection
