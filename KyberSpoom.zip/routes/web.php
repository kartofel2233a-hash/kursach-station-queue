<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/', function () {
    return redirect()->route('home'); // Перенаправлення на домашню сторінку
})->name('root');

// Головна сторінка після входу
Route::get('/home', function () {
    return view('home');
})->middleware(['auth'])->name('home');

// Сторінка входу
Route::get('/login', function () {
    return view('auth.login');
})->name('login');

// Панель управління
Route::middleware('auth')->group(function () {
    Route::get('/admin', function () {
        return view('admin.index');
    })->name('admin.index');
});

// Дашборд
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});

// Профіль користувача
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Маршрут для виходу
Route::post('/logout', function (Illuminate\Http\Request $request) {
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();
    return redirect('/login'); // Перенаправлення на сторінку входу
})->name('logout');

// Керування товарами та категоріями
Route::middleware('auth')->group(function () {
    Route::resource('products', ProductController::class);
    Route::resource('categories', CategoryController::class);
});

// Маршрут для списку товарів
Route::get('/products', [ProductController::class, 'index'])->name('products.index');

// Магазин
Route::get('/shop', [ProductController::class, 'shop'])->name('products.shop');
Route::get('/shop/{product}', [ProductController::class, 'show'])->name('products.shop.show');

// Включення маршрутів для аутентифікації
require __DIR__ . '/auth.php';
