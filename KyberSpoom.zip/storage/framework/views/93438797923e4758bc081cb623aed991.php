

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Управління товарами</h1>

        <!-- Кнопка додавання нового товару -->
        <div class="mb-6">
            <a href="<?php echo e(route('products.create')); ?>" class="bg-neonBlue text-background font-bold py-3 px-6 rounded hover:bg-cyberYellow">
                Додати товар
            </a>
        </div>

        <!-- Таблиця товарів -->
        <table class="w-full text-lightPurple border-collapse border border-darkPurple">
            <thead>
                <tr class="bg-darkPurple text-neonPink">
                    <th class="border border-darkPurple px-4 py-2">ID</th>
                    <th class="border border-darkPurple px-4 py-2">Назва</th>
                    <th class="border border-darkPurple px-4 py-2">Опис</th>
                    <th class="border border-darkPurple px-4 py-2">Ціна</th>
                    <th class="border border-darkPurple px-4 py-2">Категорія</th>
                    <th class="border border-darkPurple px-4 py-2">Дії</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td class="border border-darkPurple px-4 py-2"><?php echo e($product->id); ?></td>
                        <td class="border border-darkPurple px-4 py-2"><?php echo e($product->name); ?></td>
                        <td class="border border-darkPurple px-4 py-2"><?php echo e($product->description); ?></td>
                        <td class="border border-darkPurple px-4 py-2">$<?php echo e($product->price); ?></td>
                        <td class="border border-darkPurple px-4 py-2">
                            <?php echo e($product->category ? $product->category->name : 'Без категорії'); ?>

                        </td>
                        <td class="border border-darkPurple px-4 py-2">
                            <a href="<?php echo e(route('products.edit', $product)); ?>" class="bg-neonBlue text-background py-2 px-4 rounded hover:bg-cyberYellow">
                                Редагувати
                            </a>
                            <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded hover:bg-red-700">
                                    Видалити
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/products/index.blade.php ENDPATH**/ ?>