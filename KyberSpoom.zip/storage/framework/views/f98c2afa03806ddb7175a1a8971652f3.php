

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Магазин товарів</h1>

        <!-- Пошук і фільтрація -->
        <form method="GET" action="<?php echo e(route('products.shop')); ?>" class="mb-6 flex flex-col lg:flex-row gap-4">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Пошук товарів..." class="w-full lg:w-1/3 p-2 rounded bg-darkPurple text-white">
            <select name="category" class="w-full lg:w-1/3 p-2 rounded bg-darkPurple text-white">
                <option value="">Усі категорії</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="bg-neonBlue text-background font-bold py-2 px-6 rounded hover:bg-cyberYellow">
                Застосувати
            </button>
        </form>

        <!-- Список товарів -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-darkPurple p-4 rounded shadow-lg text-center">
            <?php if($product->image): ?>
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="mb-4 rounded max-h-40 mx-auto">
            <?php else: ?>
                <img src="<?php echo e(asset('default-product.png')); ?>" alt="Default Image" class="mb-4 rounded max-h-40 mx-auto">
            <?php endif; ?>
            <h2 class="text-neonPink text-2xl mb-4"><?php echo e($product->name); ?></h2>
            <p class="text-lightPurple mb-4">Ціна: $<?php echo e($product->price); ?></p>
            <a href="<?php echo e(route('products.shop.show', $product)); ?>" class="bg-neonBlue text-background py-2 px-4 rounded hover:bg-cyberYellow">
                Детальніше
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-lightPurple text-center col-span-3">Немає товарів за вашим запитом.</p>
    <?php endif; ?>
</div>


        <!-- Пагінація -->
        <div class="mt-6">
            <?php echo e($products->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/shop/index.blade.php ENDPATH**/ ?>