<?php $__env->startSection('content'); ?>
    <div class="flex justify-center items-center min-h-screen bg-background">
        <div class="p-6 bg-darkPurple rounded shadow-lg animate__animated animate__fadeIn">
            <h1 class="text-neonPink text-3xl font-cyber mb-4 text-center">Реєстрація в KyberSpoom</h1>
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="name" class="block text-lightPurple">Ім'я</label>
                    <input id="name" type="text" name="name" required
                        class="w-full p-2 rounded bg-gridLines text-white focus:outline-none focus:ring-2 focus:ring-neonBlue">
                </div>
                <div class="mb-4">
                    <label for="email" class="block text-lightPurple">Email</label>
                    <input id="email" type="email" name="email" required
                        class="w-full p-2 rounded bg-gridLines text-white focus:outline-none focus:ring-2 focus:ring-neonBlue">
                </div>
                <div class="mb-4">
                    <label for="password" class="block text-lightPurple">Password</label>
                    <input id="password" type="password" name="password" required
                        class="w-full p-2 rounded bg-gridLines text-white focus:outline-none focus:ring-2 focus:ring-neonBlue">
                </div>
                <div class="mb-4">
                    <label for="password_confirmation" class="block text-lightPurple">Підтвердити пароль</label>
                    <input id="password_confirmation" type="password" name="password_confirmation" required
                        class="w-full p-2 rounded bg-gridLines text-white focus:outline-none focus:ring-2 focus:ring-neonBlue">
                </div>
                <button type="submit" class="w-full bg-neonPink text-white py-2 rounded hover:bg-neonBlue">
                    Зареєструватися
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/auth/register.blade.php ENDPATH**/ ?>