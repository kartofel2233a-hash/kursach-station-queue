<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="text-5xl text-neonBlue animate__animated animate__fadeInDown">Ласкаво просимо до KyberSpoom!</h1>
        <p class="text-lightPurple mt-4 animate__animated animate__fadeInUp">Кіберпанковий магазин для сучасних технологій.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/welcome.blade.php ENDPATH**/ ?>