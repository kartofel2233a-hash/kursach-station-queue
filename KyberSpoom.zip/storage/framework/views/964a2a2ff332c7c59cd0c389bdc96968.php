<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KyberSpoom</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-background text-white">

    <!-- Кнопка "На головну" -->
    <div class="w-full bg-darkPurple py-4 px-6 flex justify-end">
        <a href="<?php echo e(route('home')); ?>" class="bg-cyberYellow text-black font-bold py-2 px-4 rounded hover:bg-cyberBlue transition">
            На головну
        </a>
    </div>

    <!-- Основний контент -->
    <div class="container mx-auto py-6">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
</body>
</html>
<?php /**PATH C:\laragon\www\KyberSpoom\resources\views/layouts/app.blade.php ENDPATH**/ ?>