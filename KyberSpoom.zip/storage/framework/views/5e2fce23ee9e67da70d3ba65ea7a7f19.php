

<?php $__env->startSection('content'); ?>
    <div style="display: flex; flex-direction: row; height: 100vh; background-color: #0f0f0f; padding: 16px;">
        <!-- Ліва частина: Постер -->
        <div style="flex: 1; display: flex; justify-content: center; align-items: center; padding-right: 16px;">
            <img src="<?php echo e(asset('A_cyberpunk-themed_poster_for_a_futuristic_tech_st.png')); ?>" alt="KyberSpoom Poster" style="max-width: 90%; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);">
        </div>

        <!-- Права частина: Текст і функціонал -->
        <div style="flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: flex-start; color: #ffe600; padding-left: 16px;">
            <h1 style="font-size: 2.5rem; color: #ff007c; font-family: 'Press Start 2P', cursive; margin-bottom: 16px;">
                Ласкаво просимо до KyberSpoom
            </h1>
            <p style="font-size: 1.25rem; color: #7b2cbf; margin-bottom: 24px;">
                Ваш портал у світ майбутніх технологій. Насолоджуйтеся найновішими продуктами у кіберпанковому стилі.
            </p>
            <!-- Кнопка для переходу на сторінку товарів -->
            <a href="<?php echo e(route('products.shop')); ?>" style="background-color: #00d9ff; color: #0f0f0f; font-weight: bold; padding: 12px 24px; border-radius: 4px; cursor: pointer; text-decoration: none; transition: 0.3s; display: inline-block; margin-bottom: 10px;">
                Переглянути товари
            </a>
            <!-- Кнопка для переходу до панелі управління -->
            <a href="<?php echo e(route('admin.index')); ?>" style="background-color: #ff007c; color: #0f0f0f; font-weight: bold; padding: 12px 24px; border-radius: 4px; cursor: pointer; text-decoration: none; transition: 0.3s; display: inline-block; margin-bottom: 10px;">
                Панель управління
            </a>
            <!-- Кнопка для редагування профілю -->
            <a href="<?php echo e(route('profile.edit')); ?>" style="background-color: #ffe600; color: #0f0f0f; font-weight: bold; padding: 12px 24px; border-radius: 4px; cursor: pointer; text-decoration: none; transition: 0.3s; display: inline-block; margin-bottom: 10px;">
                Редагувати профіль
            </a>
            <!-- Кнопка для виходу -->
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background-color: #d9534f; color: #fff; font-weight: bold; padding: 12px 24px; border-radius: 4px; cursor: pointer; border: none; transition: 0.3s;">
                    Вийти
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/home.blade.php ENDPATH**/ ?>