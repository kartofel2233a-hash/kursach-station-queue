

<?php $__env->startSection('content'); ?>
    <div style="min-height: 100vh; background-color: #0f0f0f; padding: 32px; display: flex; flex-direction: column; align-items: center; gap: 32px;">
        <!-- Заголовок -->
        <h1 style="font-size: 3rem; color: #ff007c; font-family: 'Press Start 2P', cursive; text-align: center; margin-bottom: 16px;">
            Панель управління
        </h1>

        <!-- Контейнер для зображень -->
        <div style="display: flex; align-items: center; justify-content: center; gap: 64px;">
            <!-- Зображення для переходу до сторінки товарів -->
            <a href="<?php echo e(route('products.index')); ?>" style="display: block; max-width: 400px; transition: transform 0.3s;">
                <img src="<?php echo e(asset('product-management-poster.png')); ?>" alt="Manage Products" style="width: 100%; border-radius: 16px; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.8); cursor: pointer;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
            </a>

            <!-- Зображення для переходу до сторінки категорій -->
            <a href="<?php echo e(route('categories.index')); ?>" style="display: block; max-width: 400px; transition: transform 0.3s;">
                <img src="<?php echo e(asset('category-management-poster.png')); ?>" alt="Manage Categories" style="width: 100%; border-radius: 16px; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.8); cursor: pointer;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/admin/index.blade.php ENDPATH**/ ?>