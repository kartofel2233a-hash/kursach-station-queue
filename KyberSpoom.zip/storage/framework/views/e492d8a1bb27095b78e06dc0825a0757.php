

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Редагувати товар</h1>

        <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-4">
                <label for="name" class="block text-lightPurple mb-2">Назва:</label>
                <input type="text" name="name" id="name" value="<?php echo e($product->name); ?>" class="w-full p-2 rounded bg-darkPurple text-white" required>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-lightPurple mb-2">Опис:</label>
                <textarea name="description" id="description" class="w-full p-2 rounded bg-darkPurple text-white" required><?php echo e($product->description); ?></textarea>
            </div>
            <div class="mb-4">
                <label for="price" class="block text-lightPurple mb-2">Ціна:</label>
                <input type="number" name="price" id="price" value="<?php echo e($product->price); ?>" class="w-full p-2 rounded bg-darkPurple text-white" required>
            </div>
            <div class="mb-4">
                <label for="category_id" class="block text-lightPurple mb-2">Категорія:</label>
                <select name="category_id" id="category_id" class="w-full p-2 rounded bg-darkPurple text-white" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-4">
                <label for="image" class="block text-lightPurple mb-2">Зображення (необов'язково):</label>
                <input type="file" name="image" id="image" class="w-full p-2 bg-darkPurple text-lightPurple">
            </div>
            <button type="submit" class="bg-neonBlue text-background font-bold py-3 px-6 rounded hover:bg-cyberYellow">
                Зберегти
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/products/edit.blade.php ENDPATH**/ ?>