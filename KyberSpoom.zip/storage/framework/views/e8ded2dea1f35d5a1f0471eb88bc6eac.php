

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Управління категоріями</h1>

        <!-- Кнопка додавання нової категорії -->
        <div class="mb-6">
            <a href="<?php echo e(route('categories.create')); ?>" class="bg-neonBlue text-background font-bold py-3 px-6 rounded hover:bg-cyberYellow">
                Додати категорію
            </a>
        </div>

        <!-- Таблиця категорій -->
        <table class="w-full text-lightPurple border-collapse border border-darkPurple">
            <thead>
                <tr class="bg-darkPurple text-neonPink">
                    <th class="border border-darkPurple px-4 py-2">ID</th>
                    <th class="border border-darkPurple px-4 py-2">Назва</th>
                    <th class="border border-darkPurple px-4 py-2">Опис</th>
                    <th class="border border-darkPurple px-4 py-2">Дії</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td class="border border-darkPurple px-4 py-2"><?php echo e($category->id); ?></td>
                        <td class="border border-darkPurple px-4 py-2"><?php echo e($category->name); ?></td>
                        <td class="border border-darkPurple px-4 py-2"><?php echo e($category->description); ?></td>
                        <td class="border border-darkPurple px-4 py-2">
                            <a href="<?php echo e(route('categories.edit', $category)); ?>" class="bg-neonBlue text-background py-2 px-4 rounded hover:bg-cyberYellow">
                                Редагувати
                            </a>
                            <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded hover:bg-red-700">
                                    Видалити
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/categories/index.blade.php ENDPATH**/ ?>