

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-background p-6">
        <h1 class="text-4xl font-cyber text-neonPink mb-6">Додати нову категорію</h1>

        <form action="<?php echo e(route('categories.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="name" class="block text-lightPurple mb-2">Назва:</label>
                <input type="text" name="name" id="name" class="w-full p-2 rounded bg-darkPurple text-white" required>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-lightPurple mb-2">Опис:</label>
                <textarea name="description" id="description" class="w-full p-2 rounded bg-darkPurple text-white"></textarea>
            </div>
            <button type="submit" class="bg-neonBlue text-background font-bold py-3 px-6 rounded hover:bg-cyberYellow">
                Зберегти
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\KyberSpoom\resources\views/categories/create.blade.php ENDPATH**/ ?>